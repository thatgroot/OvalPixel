# deploy the OvalPixel token using remix

  1. compile with 0.8.18
  2. deploy the contract
  3. make user to check `Deploy with Proxy` under the deploy button
  3. copy the contract

# deploy the OvalPixelV2 token

  1. compile with 0.8.18
  2. deploy the contract
  3. make user to check `Upgrade with Proxy` under the deploy button, and for proxy address use the proxy contract address
  3. copy the contract
